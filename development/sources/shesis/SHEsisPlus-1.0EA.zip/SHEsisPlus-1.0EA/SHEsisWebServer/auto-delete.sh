find /results/git/SHEsis/SHEsisWebServer/public/tmp/* -mtime +20 -exec rm -f {} \;
